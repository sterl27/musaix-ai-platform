<?php

declare( strict_types=1 );

namespace Rowbot\URL\Exception;

use Exception;

class URLException extends Exception {
}
