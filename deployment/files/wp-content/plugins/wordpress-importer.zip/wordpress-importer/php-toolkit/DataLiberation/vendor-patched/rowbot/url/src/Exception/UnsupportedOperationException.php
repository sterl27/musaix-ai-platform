<?php

declare( strict_types=1 );

namespace Rowbot\URL\Exception;

class UnsupportedOperationException extends URLException {
}
