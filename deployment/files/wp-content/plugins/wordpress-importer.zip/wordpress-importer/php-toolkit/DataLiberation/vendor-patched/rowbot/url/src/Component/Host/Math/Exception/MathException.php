<?php

declare( strict_types=1 );

namespace Rowbot\URL\Component\Host\Math\Exception;

use Rowbot\URL\Exception\URLException;

class MathException extends URLException {
}
