<?php

declare( strict_types=1 );

namespace Rowbot\Punycode\Exception;

class InvalidInputException extends PunycodeException {
}
