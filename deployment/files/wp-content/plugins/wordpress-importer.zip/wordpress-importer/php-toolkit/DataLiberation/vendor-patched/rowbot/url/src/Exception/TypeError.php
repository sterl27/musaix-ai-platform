<?php

declare( strict_types=1 );

namespace Rowbot\URL\Exception;

class TypeError extends URLException {
}
