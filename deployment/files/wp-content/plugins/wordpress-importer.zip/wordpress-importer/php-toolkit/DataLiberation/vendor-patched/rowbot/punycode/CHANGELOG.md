# Changelog

## [Unreleased]

## [1.0.4] - 2024-05-02

### Fixed

-   Fix implicit nullable deprecation warning for PHP 8.4

## [1.0.3] - 2022-01-10

### Changed

-   Update PHPstan to 1.0
-   Switched to GitHub Actions

## [1.0.2] - 2020-07-15

### Added

-   Minor performance improvements

## [1.0.1] - 2020-06-16

### Fixed

-   When calling `Punycode::decode()`, the case flags array would fail to populate when given an empty array.

## [1.0.0] - 2020-06-09

-   Initial release
