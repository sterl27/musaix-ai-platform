<?php

declare( strict_types=1 );

namespace Rowbot\URL\State;

class HostState extends AbstractHostState {
}
