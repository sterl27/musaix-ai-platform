<?php

declare( strict_types=1 );

namespace Rowbot\Punycode\Exception;

final class OverflowException extends PunycodeException {
}
