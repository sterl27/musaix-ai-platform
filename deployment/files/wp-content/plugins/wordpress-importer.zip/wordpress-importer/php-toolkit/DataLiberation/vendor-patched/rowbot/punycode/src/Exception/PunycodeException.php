<?php

declare( strict_types=1 );

namespace Rowbot\Punycode\Exception;

use Exception;

class PunycodeException extends Exception {
}
