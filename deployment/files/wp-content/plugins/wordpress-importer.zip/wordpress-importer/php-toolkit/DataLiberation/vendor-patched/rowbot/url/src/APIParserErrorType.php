<?php

declare( strict_types=1 );

namespace Rowbot\URL;

class APIParserErrorType {
	public const NONE = 'none';
	public const URL = 'url';
	public const BASE = 'base';
}
