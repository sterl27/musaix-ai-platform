# Vendor Patches

The libraries in this directory have been downgraded to PHP 7.2 compatibility using Rector
and some manual fixes.
