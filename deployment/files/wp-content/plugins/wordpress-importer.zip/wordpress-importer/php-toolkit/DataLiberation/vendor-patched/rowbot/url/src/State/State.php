<?php

declare( strict_types=1 );

namespace Rowbot\URL\State;

interface State {
}
