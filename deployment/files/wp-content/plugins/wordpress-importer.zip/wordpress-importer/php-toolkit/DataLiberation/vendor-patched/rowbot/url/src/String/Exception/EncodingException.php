<?php

declare( strict_types=1 );

namespace Rowbot\URL\String\Exception;

use Rowbot\URL\Exception\URLException;

class EncodingException extends URLException {
}
