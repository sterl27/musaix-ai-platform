<?php

declare( strict_types=1 );

namespace Rowbot\URL\String;

/**
 * @extends AbstractStringList<USVStringInterface>
 */
class StringList extends AbstractStringList implements StringListInterface {
}
