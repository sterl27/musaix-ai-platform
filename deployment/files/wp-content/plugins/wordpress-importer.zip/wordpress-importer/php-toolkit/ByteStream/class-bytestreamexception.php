<?php

namespace WordPress\ByteStream;

use Exception;

class ByteStreamException extends Exception {

}
