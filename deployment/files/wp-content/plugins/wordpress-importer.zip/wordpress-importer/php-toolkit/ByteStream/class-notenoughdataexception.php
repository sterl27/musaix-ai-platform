<?php

namespace WordPress\ByteStream;

class NotEnoughDataException extends ByteStreamException {
}
